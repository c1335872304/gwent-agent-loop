import { useEffect, useMemo, useState } from "react"

import { previewTeacherTurn } from "../api/teacher"
import type { GameState, TeacherLevel, TeacherResponse, TeacherTurnResponse } from "../types/game"

const levelLabels: Record<TeacherLevel, string> = {
  beginner: "新手",
  intermediate: "进阶",
  advanced: "高级",
}

const stoppedLabels: Record<string, string> = {
  action_chain_resolved: "本次指导动作及必要选择已完成",
  human_turn_finished: "当前回合结束",
  game_finished: "对局结束",
  budget_exceeded: "达到安全步数上限",
}

function teacherStateSignature(game: GameState): string {
  const summary = game.summary
  const actions = game.actions.map((action) => `${action.index}:${action.stable_hash}`).join("|")
  const objects = game.objects
    .map((item) => `${item.entity_id}:${item.zone}:${item.row}:${item.slot}:${item.power}:${item.armor}:${item.status.join(",")}`)
    .join("|")
  return [
    game.mode,
    summary.round,
    summary.turn,
    summary.actor,
    summary.decision,
    summary.done,
    actions,
    objects,
    game.checkpoint_update,
  ].join(";")
}

function TurnStep({ step, index }: { step: TeacherResponse; index: number }) {
  return (
    <article className="teacher-turn-step">
      <header>
        <strong>第 {index + 1} 步 · {step.action_label}</strong>
        <span>只读推演</span>
      </header>
      <p>{step.explanation}</p>
      <div className="teacher-metrics">
        {step.policy_probability !== null && <span>动作概率 {(step.policy_probability * 100).toFixed(1)}%</span>}
        {step.state_value !== null && <span>局面价值 {step.state_value.toFixed(3)}</span>}
      </div>
      {step.grounded_facts.length > 0 && (
        <details className="teacher-details">
          <summary>查看这一步的解释依据</summary>
          <ul>
            {step.grounded_facts.map((fact, factIndex) => <li key={`${factIndex}-${fact}`}>{fact}</li>)}
          </ul>
        </details>
      )}
    </article>
  )
}

function TurnAnswer({ response }: { response: TeacherTurnResponse }) {
  const stopped = stoppedLabels[response.stopped_reason] ?? response.stopped_reason
  return (
    <div className="teacher-answer">
      <h3>{response.headline}</h3>
      <p>{response.explanation}</p>
      <p className="teacher-turn-stop">停止原因：{stopped}</p>
      <div className="teacher-turn-steps">
        {response.steps.map((step, index) => <TurnStep key={`${step.decision_serial ?? index}-${step.action_label}`} step={step} index={index} />)}
      </div>
      {response.caveats.length > 0 && <p className="teacher-caveat">{response.caveats.at(-1)}</p>}
    </div>
  )
}

export function TeacherPanel({ game }: { game: GameState }) {
  const signature = useMemo(() => teacherStateSignature(game), [game])
  const canPreview = game.mode === "human_vs_ai"
    && !game.summary.done
    && game.summary.actor === 0
    && game.summary.decision === "turn"
    && game.actions.length > 0
  const [level, setLevel] = useState<TeacherLevel>("beginner")
  const [response, setResponse] = useState<TeacherTurnResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!canPreview) {
      setResponse(null)
      setError(null)
      setLoading(false)
      return
    }

    let cancelled = false
    setLoading(true)
    setError(null)
    void previewTeacherTurn(level)
      .then((result) => {
        if (cancelled) return
        if (!result.ok || !result.response) {
          setResponse(null)
          setError(result.error ?? "教师暂时无法推演当前回合。")
          return
        }
        setResponse(result.response)
      })
      .catch((exc) => {
        if (cancelled) return
        setResponse(null)
        setError(exc instanceof Error ? exc.message : String(exc))
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [canPreview, level, signature])

  const unavailableReason = game.mode !== "human_vs_ai"
    ? "双人测试模式不调用教师推演。"
    : game.summary.done
      ? "对局已经结束，无法推演当前回合。"
      : game.summary.actor !== 0
        ? "正在等待人类获得控制权后再推演。"
        : game.summary.decision !== "turn"
          ? "请先完成当前的换牌或必选步骤，再生成 AI 指导动作。"
        : "当前没有可推演的合法动作。"

  return (
    <section className="panel teacher-panel">
      <div className="teacher-panel__header">
        <div>
          <span className="teacher-kicker">READ-ONLY TURN SIMULATION</span>
          <h2>AI 教师</h2>
        </div>
        <select
          aria-label="教师解释级别"
          value={level}
          disabled={loading || !canPreview}
          onChange={(event) => setLevel(event.target.value as TeacherLevel)}
        >
          {(Object.keys(levelLabels) as TeacherLevel[]).map((item) => (
            <option key={item} value={item}>{levelLabels[item]}</option>
          ))}
        </select>
      </div>

      <p className="teacher-mode-note">当前回合 AI 接管推演 · 未执行，不会修改真实对局。</p>

      {!canPreview ? (
        <p className="empty">{unavailableReason}</p>
      ) : loading ? (
        <p className="muted">正在根据当前局面推演完整回合……</p>
      ) : error ? (
        <div className="teacher-unavailable">
          <strong>教师暂不可用</strong>
          <span>{error}</span>
          <small>这不会影响游戏或 AI 决策。</small>
        </div>
      ) : response ? <TurnAnswer response={response} /> : null}
    </section>
  )
}
