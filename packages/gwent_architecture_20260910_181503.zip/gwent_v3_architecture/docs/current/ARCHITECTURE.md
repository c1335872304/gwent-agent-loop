# System Architecture

当前源码、Docker runtime、模型 contract 和已验证链路的基线见
[`PROJECT_BASELINE.md`](PROJECT_BASELINE.md)。本文描述稳定的分层结构；不要把旧计划文档当成当前运行态。

## 1. Development Plane

```text
                         Change Request
                               │
          ┌────────────────────┼────────────────────┐
          ▼                    ▼                    ▼
      Core Agent           Trainer Agent        Product Agent
          │                    │                    │
 $core-environment     $training-config   $product-integration
          │                    │                    │
          └──────────── contracts / tests ──────────┤
                                                    ▼
                                              Teacher Agent
                                         $teacher-explanation
                                                    │
                                                    ▼
                                            Validated Change
```

Development Plane 负责约束“代码怎么被修改”，不参与游戏运行。

## 2. Runtime Plane

```text
                         V3 checkpoint
                              │
                              ▼
+----------------+      +------------------+
| C++ Game Core  | ---> | Strategy Core    |
| state / rules  | <--- | policy + value   |
+-------+--------+      +---------+--------+
        │                         │ executed action
        │ public state            │ evidence
        ▼                         ▼
+----------------+        +------------------+
| FastAPI BFF    | <----- | Teacher Runtime  |
+-------+--------+        +------------------+
        │
        ▼
+----------------+
| React Frontend |
+----------------+
```

## 3. 权威边界

### Game Core

- 唯一规则事实来源；
- 生成 legal actions；
- 执行 action 并推进状态；
- 暴露 C ABI / observation / trace。

### Strategy Core

- 不重新判断合法性；
- 只对 Core action candidates 打分；
- 输出 policy、value、执行动作和可解释 evidence。

### Teacher Runtime

- 只读；
- 不修改动作；
- 不参与训练 reward；
- 不把隐藏候选或 AI 手牌返回给人类玩家。

对“当前人类回合 AI 接管推演”，Core 会先 clone 环境，再在 clone 中执行正式策略。clone 必须与真实
`ResolutionFrame`、decision prefix、预算和回滚快照隔离；Teacher 只消费已经生成的 branch trace。

### Web Product

- BFF 负责 contract 校验与服务编排；
- React 负责交互与展示；
- 不直接加载 C++ shared library 或 `.pt`；
- 不解析文本 label 反推规则。

## 4. 数据流

```text
Core GameState
   │
   ├─> legal actions ─> Strategy ─> chosen option_index ─> Core step
   │                         │
   │                         └─> decision evidence
   │                                   │
   └─> public state --------------------┼─> Teacher
                                       │
                                       └─> BFF ─> React panel
```

## 5. 训练与产品隔离

训练系统负责 collector、PPO、checkpoint 和 evaluation；产品 runtime 只加载封盘 checkpoint。服务器训练目录、optimizer state 和历史 update 不属于产品依赖。

## 6. 本地产品部署

本地 CPU 单机产品使用 `deploy/docker/compose.cpu.yml`，将已有运行边界封装为 Compose 服务：

```text
Browser :8080
    │
    ▼
web (Nginx) ──> bff (FastAPI) ──> core (C++ + final policy.pt)
                                           │
                                           └──> teacher（可选、只读）
```

- 宿主机只发布 Web；Core、BFF、Teacher 留在 Compose 内部网络；
- 本地必需资产只有最终 `models/v3/policy.pt`，以只读卷挂载；
- `installed.json` 是可选的本地来源记录；不要求下载服务器的中间 checkpoint 或训练目录；
- 该部署不改变 Core 规则、RL contract 或 Product HTTP contract。
